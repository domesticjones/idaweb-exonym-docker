<?php get_template_part('page'); ?>
