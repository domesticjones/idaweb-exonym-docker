<?php
  the_sub_field('content');
  echo ex_cta();
?>
